# 妄想路線バス 1.1.0 同梱の地理・路線データ

この配布物は、妄想路線バス 1.1.0 のアプリに同梱する、機械可読な完成データを無料で提供するものです。1.1.0の公開メニューは無料8系統15方向と拡張パック7系統14方向です。アプリにはメニューで選べない検証用も含め、36個の路線JSONと共通構造物JSON1個を同梱します。この配布物にも同じ37ファイルを含めます。追加採用を検討中の候補路線データは含めません。一般利用者が作成・保存した路線や設定は含みません。

## ライセンス

© OpenStreetMap contributors

OpenStreetMap由来の地理データを含みます。道路、交差点、信号、鉄道、歩道橋、水域、公園、建物輪郭等を抽出し、路線経路、走行線、車線・高さの補正、構造物の概形等に加工しています。OSM由来のデータベースと本配布物のデータベースとしての改変部分は、Open Database License (ODbL) 1.0 の条件で提供します。

- OpenStreetMapの著作権・ライセンス案内: https://www.openstreetmap.org/copyright
- ODbL 1.0: https://opendatacommons.org/licenses/odbl/1-0/
- ライセンス全文: ODbL-1.0.txt

ODbLが対象とするデータベースの権利と、個々の内容物が元から持つ権利は区別されます。以下の原データの出典・ライセンスも維持してください。独自の推定・追加内容は、第三者の内容物の権利を変更しません。著作権・データベース権が当方に帰属する追加分は、本配布データベースに含めてODbL 1.0で提供します（加工・追加: © 2026 thivanao）。

## 個々の内容物の出典

- 東京都交通局・公共交通オープンデータ協議会「東京都交通局 バス関連情報」GTFS、版20261111_030718。停留所・運行の元データをCC BY 4.0で利用し、停留所位置・経路・ダイヤ等をアプリ用に加工しています。配布元: https://www.odpt.org/ / https://ckan.odpt.org/ 。
- 名古屋市交通局「市バス GTFS-JP」、版202603_02。CC BY 4.0。停留所名・標柱座標・選択便の元時刻を利用。元GTFSに経路形状はなく、OSM道路から参考経路を作成し、停留所位置・走行時間を調整しています。配布元: https://data.bodik.jp/dataset/231002_7109030000_bus-gtfs-jp 。
- CC BY 4.0の条件: https://creativecommons.org/licenses/by/4.0/
- 復刻虹01は過去の公開案内を参考に、現代の道路で再構成。旧停留所座標は推定、ダイヤは独自です。空港連絡も公開案内の発着地・停車順を参考に道路上へ再構成し、経路・標柱位置は推定、ダイヤは独自です。原案内のPDFや画像は本配布物には含みません。各路線JSONのsourceとreferenceの記録を参照してください。

## ファイルと改変

routes/*.json と structures/tokyo-structures.json は、1.1.0に同梱する同名のJSONとバイト単位で同じです。道路のつながり・車線数・停留所位置・標高・構造物には推定と簡略化があり、実際の交通案内・ナビゲーションには使えません。取得時期等は各JSONのsourceを参照してください。

source-manifest.json に全37ファイルのサイズとSHA-256を記録しています。国土地理院の航空写真・標高・背景地図画像、PLATEAUの3D Tiles、アプリのプログラム、生成ロゴ・アイコン、個人の保存情報は、このデータ配布物には含めていません。

この提供はデータの再利用用です。アプリのプログラム、名称・標章、交通事業者との提携や承認について権利を与えるものではありません。交通事業者の標章・塗装は使っていません。

問い合わせ: thivanao@gmail.com
作成日: 2026-11-16

## English summary

This is the free, machine-readable offer of the completed geographic/route database bundled in Mousou Bus Ride 1.1.0. The 36 route JSON files and one common structure JSON are byte-identical to the app assets, including bundled data not selectable in the public menu. Future route candidates, user-created routes/settings, program code and remote scenery assets are excluded.

© OpenStreetMap contributors. The OSM-derived database and our database modifications are offered under ODbL 1.0 (see ODbL-1.0.txt). Individual contents retain their source notices: Tokyo Metropolitan Bureau of Transportation / Association for Open Data of Public Transportation GTFS and Transportation Bureau, City of Nagoya GTFS-JP are used under CC BY 4.0. Niji01 and airport routes use estimated geometry/stop locations and original timetables; reference information is recorded in each JSON. This data is not real travel guidance and does not imply any transport operator's approval. See source-manifest.json for every file's SHA-256 and size.
